﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TikBot.Models
{
    public class Mentor
    {
        public string FullName { get; set; }
        public long ChatId { get; set; }
        public long UpgradeGroupId { get; set; }
    }
}
