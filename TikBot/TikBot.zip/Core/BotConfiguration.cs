﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TikBot.Core
{
    public static class BotConfiguration
    {
        public const string Token = "7846580828:AAH4wxjHdiharAxURfgkj9kciN5G4rVCDFw";
    }
}
